<?php
session_start();
$total = 0;
?>

<h1>Keranjang Belanja</h1>

<table border="1" cellpadding="10">
<tr>
  <th>Nama Produk</th>
  <th>Jumlah</th>
  <th>Harga</th>
  <th>Total</th>
</tr>

<?php foreach ($_SESSION['cart'] as $item) : 
    $subtotal = $item['price'] * $item['qty'];
    $total += $subtotal;
?>
<tr>
  <td><?= $item['name']; ?></td>
  <td><?= $item['qty']; ?></td>
  <td>Rp<?= number_format($item['price']); ?></td>
  <td>Rp<?= number_format($subtotal); ?></td>
</tr>
<?php endforeach; ?>
</table>

<h2>Total Belanja: Rp<?= number_format($total); ?></h2>

<a href="menu.php">Belanja Lagi</a>
<a href="checkout.php">Checkout</a>