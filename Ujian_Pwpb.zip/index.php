<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <header class="topbar">
    <div class="brand">
    <img src="img/Best-removebg-preview.png" width="48" height="48" alt="logo">
    </div>
    <div class="actions">
      <button class="btn secondary" id="loginBtn">Log In</button>
      <div class="cart">
        <button class="btn" id="openCart">pesanan</button>
        <div class="count" id="cartCount">0</div>
      </div>
    </div>
  </header>

  <main>
    <section class="hero">
      <div class="left">
        <h2>Super <strong>DELICOUS</strong></h2>
        <p>Promo 50% OFF — nikmati menu spesial kami sekarang juga. Free delivery untuk pesanan tertentu.</p>
        <div class="search">
          <select id="categoryFilter" style="border:0;background:transparent;padding:6px;font-weight:700">
            <option value="all">Semua</option>
            <option value="ayam">Ayam</option>
            <option value="nasi">Nasi</option>
            <option value="minuman">Minuman</option>
          </select>
          <input type="text" id="searchInput" placeholder="Cari Makanan" aria-label="Cari Makanan">
          <button class="btn" id="searchBtn">Cari</button>
        </div>
      </div>
      <img src="img/hero.png" alt="hero" />
    </section>

    <section class="filters">
      <div class="tabs">
        <div class="tab " data-filter="all">Jenis menu</div>
        <div class="tab" data-filter="termurah">Termurah</div>
        <div class="tab" data-filter="promo">Promo</div>
      </div>
    </section>
<?php
session_start();
$produk = [
    [
        "id" => 1,
        "name" => "Nasi Goreng Spesial",
        "price" => 25000,
        "image" => "",
        "category" => "nasi"
    ],
    [
        "id" => 2,
        "name" => "Ayam Bakar Taliwang",
        "price" => 30000,
        "image" => "img/ayam bakar.jpg",
        "category" => "ayam"
    ]
];
?>

<section class="menu">
  <div class="grid" id="productGrid">

    <?php foreach ($produk as $pd) : ?>
      <div class="card" data-category="<?= $pd['category']; ?>">
        <img src="<?= $pd['image']; ?>" alt="<?= $pd['name']; ?>" />

        <div class="info">
          <h3><?= $pd['name']; ?></h3>
          <div class="price">Rp<?= number_format($pd['price'], 0, ',', '.'); ?></div>

          <form action="add_cart.php" method="POST">
            <input type="hidden" name="id" value="<?= $pd['id']; ?>">
            <input type="hidden" name="name" value="<?= $pd['name']; ?>">
            <input type="hidden" name="price" value="<?= $pd['price']; ?>">
            <button type="submit" class="beli">Tambah ke Keranjang</button>
          </form>

        </div>
      </div>
    <?php endforeach; ?>

  </div>
</section>

  </main>

  <div class="modal" id="cartModal">
    <div class="head">
      <strong>Keranjang Anda</strong>
      <button id="closeCart">×</button>
    </div>
    <div class="items" id="cartItems">
    </div>
    <div class="foot">
      <div>
        <div style="font-size:14px;color:var(--muted)">Total</div>
        <div style="font-weight:800" id="cartTotal">Rp0</div>
      </div>
      <div>
        <button class="btn" id="checkoutBtn">Checkout</button>
      </div>
    </div>
  </div>

</body>
</html>